<?php $__env->startSection('konten'); ?>
    <div class="container">
        <form action="<?php echo e(route('data-odp.update', $data_odp->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label>Deskripsi:</label>
                <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama', $data_odp->nama)); ?>" required>
            </div>
            <div>
                <select name="tipe" id="tipe" required>
                    <option value="ODP" <?php echo e($data_odp->tipe == 'ODP' ? 'selected' : ''); ?>>ODP</option>
                    <option value="ODC" <?php echo e($data_odp->tipe == 'ODC' ? 'selected' : ''); ?>>ODC</option>
                    <option value="Crosure" <?php echo e($data_odp->tipe == 'Crosure' ? 'selected' : ''); ?>>Crosure</option>
                    <option value="Tiang" <?php echo e($data_odp->tipe == 'Tiang' ? 'selected' : ''); ?>>Tiang</option>
                </select>
            </div>
            <div class="form-group">
                <label>Maps:</label>
                <input type="text" name="maps" class="form-control" value="<?php echo e(old('maps', $data_odp->maps)); ?>" required>
            </div>
            <div class="form-group">
                <label>Foto:</label>
                <div>
                    <img src="<?php echo e(asset($data_odp->foto)); ?>" alt="Foto Sebelumnya" width="100" class="mb-2">
                    <input type="file" name="foto" id="foto" class="form-control">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\dashboard2\resources\views/data-odp/edit.blade.php ENDPATH**/ ?>