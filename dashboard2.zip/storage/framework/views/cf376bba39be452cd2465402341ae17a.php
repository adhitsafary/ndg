<?php $__env->startSection('konten'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2 style="font: 600" class="text-center">Edit ODP</h1>

                    <form action="<?php echo e(route('odp.update', $odp->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-3">
                            <label for="kecamatan" class="form-label">Kecamatan</label>
                            <input type="text" class="form-control" id="kecamatan" name="kecamatan"
                                value="<?php echo e($odp->kecamatan); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="desa" class="form-label">Desa</label>
                            <input type="text" class="form-control" id="desa" name="desa"
                                value="<?php echo e($odp->desa); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="dusun" class="form-label">Dusun</label>
                            <input type="text" class="form-control" id="dusun" name="dusun"
                                value="<?php echo e($odp->dusun); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="keterangan" class="form-label">Keterangan</label>
                            <input type="text" class="form-control" id="keterangan" name="keterangan"
                                value="<?php echo e($odp->keterangan); ?>">

                        </div>


                        <div class="mb-3">
                            <label for="kode_odp" class="form-label">Kode ODP</label>
                            <input type="text" class="form-control" id="kode_odp" name="kode_odp"
                                value="<?php echo e($odp->kode_odp); ?>" required>
                        </div>


                        <div class="mb-3">
                            <label for="no_urut_odp" class="form-label">No Urut ODP</label>
                            <input type="number" class="form-control" id="no_urut_odp" name="no_urut_odp"
                                value="<?php echo e($odp->no_urut_odp); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="jml_odp" class="form-label">Jumlah ODP</label>
                            <input type="text" class="form-control" id="jml_odp" name="jml_odp"
                                value="<?php echo e($odp->jml_odp); ?>" required>
                        </div>


                        <div class="mb-3">
                            <label for="jml_port" class="form-label">Jumlah Port</label>
                            <input type="number" class="form-control" id="jml_port" name="jml_port"
                                value="<?php echo e($odp->jml_port); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="longitude" class="form-label">Longitude</label>
                            <input type="text" class="form-control" id="longitude" name="longitude"
                                value="<?php echo e($odp->longitude); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="latitude" class="form-label">Latitude</label>
                            <input type="text" class="form-control" id="latitude" name="latitude"
                                value="<?php echo e($odp->latitude); ?>">
                        </div>

                        <button type="submit" class="btn btn-success">Perbarui ODP</button>
                        <a href="<?php echo e(route('odp.index')); ?>" class="btn btn-secondary">Batal</a>
                    </form>

                    <form action="<?php echo e(route('odp.destroy', $odp->id)); ?>" method="POST" style="margin-top: 20px;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger"
                            onclick="return confirm('Apakah Anda yakin ingin menghapus ODP ini?')">Hapus ODP</button>
                    </form>
            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\dashboard2\resources\views/odp/edit.blade.php ENDPATH**/ ?>