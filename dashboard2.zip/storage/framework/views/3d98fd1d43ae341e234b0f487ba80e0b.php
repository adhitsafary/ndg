<?php $__env->startSection('konten'); ?>
    <div class="container">
        <h1>Edit Token WhatsApp Bot</h1>

        <form action="<?php echo e(route('bot_tokens.update', $token)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Nama Token</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e($token->name); ?>" required>
            </div>
            <div class="mb-3">
                <label for="token" class="form-label">Token</label>
                <input type="text" id="token" name="token" class="form-control" value="<?php echo e($token->token); ?>"
                    required>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\dashboard2\resources\views/bot_tokens/edit.blade.php ENDPATH**/ ?>