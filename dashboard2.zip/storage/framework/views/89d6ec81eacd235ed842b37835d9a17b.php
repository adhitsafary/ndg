<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Download Log Absensi</title>
    <style>
        body {
            background-color: #caffcb;
            font-family: Arial, sans-serif;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
    </style>
</head>

<body>

    <h3>Download Log Data</h3>

    <form action="<?php echo e(route('x100c.downloadLog')); ?>" method="GET">
        IP Address: <input type="text" name="ip" value="<?php echo e(old('ip', $IP)); ?>" size="15"><br>
        Comm Key: <input type="text" name="key" value="<?php echo e(old('key', $Key)); ?>" size="5"><br><br>
        <input type="submit" value="Download">
    </form>

    <br>

    <?php if(session('error')): ?>
        <div class="alert alert-error"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(isset($data)): ?>
        <h4>Hasil Download Log Absensi</h4>

        <table>
            <tr>
                <th>UserID</th>
                <th>Tanggal & Jam</th>
                <th>Verifikasi</th>
                <th>Status</th>
            </tr>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(htmlspecialchars($item['PIN'])); ?></td>
                    <td><?php echo e(htmlspecialchars($item['DateTime'])); ?></td>
                    <td><?php echo e(htmlspecialchars($item['Verified'])); ?></td>
                    <td><?php echo e(htmlspecialchars($item['Status'])); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endif; ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\dashboard2\resources\views/x100c/log-absensi.blade.php ENDPATH**/ ?>