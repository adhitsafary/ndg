<?php $__env->startSection('konten'); ?>
    <div class="m-5">

        <h2 style="font: 600" class="text-center">Daftar ODP</h1>

        <a href="<?php echo e(route('odp.create')); ?>" class="btn btn-danger mb-3">Tambah ODP</a>

        <table class="table table-striped table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>Nama ODP</th>
                    <th>Jumlah Pelanggan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $odps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $odp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($odp->nama_odp); ?></td>
                        <td><?php echo e($odp->jumlah_pelanggan); ?></td>
                        <td>
                            <a href="<?php echo e(route('odp.show', $odp->nama_odp)); ?>" class="btn btn-info btn-sm">Detail</a>
                            <a href="<?php echo e(route('odp.edit', $odp->id)); ?>" class="btn btn-warning btn-sm">Edit</a>

                            <!-- Form untuk menghapus ODP -->
                            <form action="<?php echo e(route('odp.destroy', $odp->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm"
                                    onclick="return confirm('Apakah Anda yakin ingin menghapus ODP ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\dashboard2\resources\views/odp/index.blade.php ENDPATH**/ ?>