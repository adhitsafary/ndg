<?php $__env->startSection('konten'); ?>

<div class="container">
    <div>
        <a href="/modem/create/" class="btn btn=primary">Tambah data</a>
    </div>
    <div class="row">
        <?php $__currentLoopData = $modem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5><?php echo e($modem->model); ?></h5>
                    </div>
                    <div class="card-body">
                        <p><strong>SN Modem:</strong> <?php echo e($modem->sn_modem); ?></p>
                        <p><strong>Tanggal Keluar:</strong> <?php echo e($modem->tgl_keluar); ?></p>
                        <p><strong>User:</strong> <?php echo e($modem->user); ?></p>
                        <p><strong>ID MikroTik:</strong> <?php echo e($modem->id_mikrotik); ?></p>
                        <p><strong>Keterangan:</strong> <?php echo e($modem->keterangan); ?></p>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('modem.edit', $modem->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('modem.destroy', $modem->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\dashboard2\resources\views/modem/index_hp.blade.php ENDPATH**/ ?>