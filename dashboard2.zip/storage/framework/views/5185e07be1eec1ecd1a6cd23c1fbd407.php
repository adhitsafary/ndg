<?php $__env->startSection('konten'); ?>
    <div class="card m-5">

        <div class="">
            <h2 style="font: 600" class="text-center">DETAIL ODP DI DESA <?php echo e(strtoupper($desa)); ?></h2>

            <a href="<?php echo e(route('odp.index')); ?>" class="btn btn-primary mb-3">Kembali</a>

            <table class="table table-striped table-bordered">
                <thead class="table-danger">
                    <tr>
                        <th>No</th>
                        <th>Kecamatan</th>
                        <th>Desa</th>
                        <th>Dusun</th>
                        <th>Keterangan</th>
                        <th>Kode ODP</th>
                        <th>Jumlah Port</th>
                        <th>No Urut ODP</th>
                        <th>Jumlah Pelanggan</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $odps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $odp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($no + 1); ?></td>
                            <td><?php echo e($odp->kecamatan); ?></td>
                            <td><?php echo e($odp->desa); ?></td>
                            <td><?php echo e($odp->dusun); ?></td>
                            <td><?php echo e($odp->keterangan); ?></td>
                            <td><?php echo e($odp->kode_odp); ?></td>
                            <td><?php echo e($odp->jml_port); ?></td>
                            <td><?php echo e($odp->no_urut_odp); ?></td>
                            <td><?php echo e($odp->jumlah_pelanggan); ?></td>
                            <td><?php echo e($odp->keterangan); ?></td>
                            <td>
                                <a href="<?php echo e(route('odp.show', $odp->kode_odp)); ?>" class="btn btn-info btn-sm">Detail</a>
                                <a href="<?php echo e(route('odp.edit', $odp->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                <form action="<?php echo e(route('odp.destroy', $odp->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm"
                                        onclick="return confirm('Apakah Anda yakin ingin menghapus ODP ini?')">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">Data tidak ditemukan</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\dashboard2\resources\views/odp/detail.blade.php ENDPATH**/ ?>