<?php $__env->startSection('konten'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1>Generator ID</h1>
                <a href="<?php echo e(route('generator_id.create')); ?>" class="btn btn-primary mb-3">Buat Generator ID</a>

                <table class="table table-bordered" style="color: black;">
                    <thead class="table table-danger" style="color: black;">
                        <tr>
                            <th>No</th>
                            <th>Kode Perusahaan</th>
                            <th>Nik</th>
                            <th>ODP</th>
                            <th>Paket</th>
                            <th>Hasil</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $generatorIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $generatorId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="font font-weight-bold" style="color: black">
                                <td><?php echo e($no + 1); ?></td>
                                <td><?php echo e($generatorId->kode_perusahaan); ?></td>
                                <td><?php echo e($generatorId->kode_nik); ?></td>
                                <td><?php echo e($generatorId->kode_odp); ?></td>
                                <td><?php echo e($generatorId->kode_paket_plg); ?></td>
                                <td>
                                    <!-- Gabungan kode perusahaan, 4 kode_nik terakhir, 3 kode_odp pertama, dan paket_plg -->
                                    <?php echo e($generatorId->kode_perusahaan . substr($generatorId->kode_nik, -4) . substr($generatorId->kode_odp, 0, 3) . $generatorId->kode_paket_plg ."@net.net"); ?>

                                </td>
                                <td> <a href="<?php echo e(route('generator_id.edit', $generatorId->id)); ?>"
                                        class="btn btn-warning btn-sm">Edit</a>

                                    <form action="<?php echo e(route('generator_id.destroy', $generatorId->id)); ?>" method="POST"
                                        class="d-inline-block">
                                        <?php echo csrf_field(); ?>

                                        <button class="btn btn-danger btn-sm"
                                            onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="13" class="text-center">Tidak ada data ditemukan</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>



            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\dashboard2\resources\views/generator_id/index.blade.php ENDPATH**/ ?>