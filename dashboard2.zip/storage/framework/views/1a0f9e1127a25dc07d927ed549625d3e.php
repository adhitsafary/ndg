<?php $__env->startSection('konten'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h1>Buat Generator ID Baru</h1>
            <form action="<?php echo e(route('generator_id.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="kode_perusahaan">Kode Perusahaan</label>
                    <input type="text" name="kode_perusahaan" class="form-control" required maxlength="10">
                </div>
                <div class="form-group">
                    <label for="kode_tahun">Kode Tahun</label>
                    <input type="text" name="kode_tahun" class="form-control" required maxlength="10">
                </div>
                <div class="form-group">
                    <label for="kode_nik">Kode NIK</label>
                    <input type="text" name="kode_nik" class="form-control" required maxlength="10">
                </div>
                <div class="form-group">
                    <label for="kode_odp">Kode ODP</label>
                    <input type="text" name="kode_odp" class="form-control" required maxlength="10">
                </div>
                <button type="submit" class="btn btn-success">Save</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\dashboard2\resources\views/generator_id/create.blade.php ENDPATH**/ ?>