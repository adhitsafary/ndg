<?php $__env->startSection('konten'); ?>
    <div class="card m-5">
        <!-- Form Filter dan Pencarian -->
        <form action="<?php echo e(route('pemasukan.index')); ?>" method="GET" class="form-inline mb-4">
            <div class="input-group">
                <input type="text" name="search" id="search" class="form-control" value="<?php echo e(request('search')); ?>"
                    placeholder="Pencarian">
                <div class="input-group-append">
                    <button type="submit" class="btn btn-danger">Cari</button>
                </div>
            </div>
        </form>

        <div class="row">
            <a href="/pemasukan/create" class="btn btn-danger mr-2 ml-3">Buat pemasukan</a>
            <a href="/pemasukan/index_jml" class="btn btn-danger">Data pemasukan 1 Bulan</a>
        </div>

        <div style="display: flex; justify-content: center;" class="mb-3">
            <h5 style="color: black;" class="font font-weight-bold">Data pemasukan</h5>
        </div>

        <table class="table table-bordered" style="color: black;">
            <thead class="table " style="color: black;">
                <tr>
                    <th>No</th>
                    <th>Deskripsi</th>
                    <th>Harga Satuan</th>
                    <th>Volume</th>
                    <th>Harga Total</th>
                    <th>Kategori</th>
                    <th>Keterangan</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $kategoriSebelumnya = null;
                    $warnaKategori = ['table-danger', 'table-success', 'table-warning', 'table-primary', 'table-info'];
                    $indexWarna = 0;
                    $totalKategori = [];
                ?>

                <?php $__currentLoopData = $pemasukan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        if (!isset($totalKategori[$item->kategori])) {
                            $totalKategori[$item->kategori] = 0;
                        }
                        $totalKategori[$item->kategori] += $item->harga_total;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__empty_1 = true; $__currentLoopData = $pemasukan->sortBy('kategori'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($kategoriSebelumnya !== $item->kategori): ?>
                        <?php
                            $kategoriSebelumnya = $item->kategori;
                            $warna = $warnaKategori[$indexWarna % count($warnaKategori)];
                            $indexWarna++;
                        ?>
                        <!-- Baris Header Kategori -->
                        <tr class="<?php echo e($warna); ?> font-weight-bold">
                            <td colspan="9"><?php echo e($item->kategori); ?></td>
                        </tr>
                    <?php endif; ?>

                    <!-- Baris Data -->
                    <tr style="color: black">
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->deskripsi); ?></td>
                        <td><?php echo e(number_format($item->harga_satuan)); ?></td>
                        <td><?php echo e(number_format($item->volume)); ?></td>
                        <td><?php echo e(number_format($item->harga_total)); ?></td>
                        <td><?php echo e($item->kategori); ?></td>
                        <td><?php echo e($item->keterangan); ?></td>
                        <td><?php echo e($item->created_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('pemasukan.edit', $item->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('pemasukan.destroy', $item->id)); ?>" method="POST"
                                class="d-inline-block">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger btn-sm"
                                    onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>

                    <?php
                        $nextItem = $pemasukan->where('kategori', $item->kategori)->last();
                    ?>

                    <?php if($item->id == $nextItem->id): ?>
                        <!-- Baris Total Kategori -->
                        <tr class="font-weight-bold bg-light">
                            <td colspan="4" class="text-right">Total <?php echo e($item->kategori); ?></td>
                            <td><?php echo e(number_format($totalKategori[$item->kategori])); ?></td>
                            <td colspan="4"></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="text-center">Tidak ada data ditemukan</td>
                    </tr>
                <?php endif; ?>

                <!-- Baris total di bawah tabel -->
                <tr class="table-dark text-black font-weight-bold">
                    <td colspan="4" class="text-center">TOTAl KESELURUHAN</td>
                    <td><?php echo e(number_format($totalJumlah)); ?></td>
                    <td colspan="3"></td>
                </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\NDG BARU\dashboard2\resources\views/pemasukan/index.blade.php ENDPATH**/ ?>