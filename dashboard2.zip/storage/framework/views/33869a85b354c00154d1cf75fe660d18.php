<?php $__env->startSection('konten'); ?>
    <diV class="card m-5">
        <div class="">
            <div class="row ml-3 mb-3 mt-1 ">

                <div class="d-flex justify-content-center">
                    <img src="<?php echo e(asset('asset/img/icon/odp2.png')); ?>" height="100px" alt="">
                </div>
                <div class="">
                    <h2 style="font: 600" class="ml-4">Detail : ODP <?php echo e($kode_odp); ?></h2>
                    <div class="row ml-4">
                        <div class="mr-4">
                            <h4 style="font-weight: 600" style="m-5">Kecamatan : <?php echo e($kecamatan); ?> </h4>
                        </div>
                        <div class="mr-4">
                            <h4 style="font-weight: 600">Desa : <?php echo e($desa); ?></h4>
                        </div>
                        <div class="mr-4">
                            <h4 style="font-weight: 600">Dusun : <?php echo e($dusun); ?></h4>
                        </div>
                        <div class="mr-4">
                            <h4 style="font-weight: 600">Jumlah ODP : <?php echo e($jml_odp); ?></h4>
                        </div>
                        <div class="mr-4">
                            <h4 style="font-weight: 600">Keterangan : <?php echo e($keterangan); ?></h4>
                        </div>
                    </div>
                </div>

            </div>
            <table class="table table-striped table-bordered">
                <thead class="table-danger">
                    <tr>
                        <th>No</th>
                        <th>Nama Pelanggan</th>
                        <th>Alamat</th>
                        <th>No Telepon</th>
                        <th>Paket</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no + 1); ?></td>
                            <td><?php echo e($pelanggan->nama_plg); ?></td>
                            <td><?php echo e($pelanggan->alamat_plg); ?></td>
                            <td><?php echo e($pelanggan->no_telepon_plg); ?></td>
                            <td><?php echo e($pelanggan->paket_plg); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </diV>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\dashboard2\resources\views/odp/show.blade.php ENDPATH**/ ?>