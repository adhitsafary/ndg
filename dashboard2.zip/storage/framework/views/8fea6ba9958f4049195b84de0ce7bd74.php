<?php $__env->startSection('konten'); ?>
    <div class="container mt-4 card">
        <h6 class="text text-center text-black mt-3"> Edit Data rekap pemasangan : <?php echo e($rekap_pemasangan->nama); ?> </h6>
        <form action="<?php echo e(route('rekap_pemasangan.update', $rekap_pemasangan->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <label for="">ID Pelanggan</label>
            <input type="text" name="id_plg" value="<?php echo e($rekap_pemasangan->id_plg); ?>" class="form-control mb-3">

            <label for="">NIK</label>
            <input type="text" name="nik" value="<?php echo e($rekap_pemasangan->nik); ?>" class="form-control mb-3">

            <label for="">Nama</label>
            <input type="text" name="nama" value="<?php echo e($rekap_pemasangan->nama); ?>" class="form-control mb-3">

            <label for="">Alamat</label>
            <input type="text" name="alamat" value="<?php echo e($rekap_pemasangan->alamat); ?>" class="form-control mb-3">

            <label for="">No Telepon</label>
            <input type="text" name="no_telpon" value="<?php echo e($rekap_pemasangan->no_telpon); ?>" class="form-control mb-3">

            <label for="">Aktivasi</label>
            <input type="date" name="tgl_aktivasi" value="<?php echo e($rekap_pemasangan->tgl_aktivasi); ?>"
                class="form-control mb-3">

            <label for="">Paket</label>
            <input type="text" name="paket_plg" value="<?php echo e($rekap_pemasangan->paket_plg); ?>" class="form-control mb-3">

            <label for="">Harga Paket</label>
            <input type="text" name="harga_paket" value="<?php echo e($rekap_pemasangan->harga_paket); ?>" class="form-control mb-3">

            <label for="">Jatuh Tempo</label>
            <input type="text" name="jt" value="<?php echo e($rekap_pemasangan->jt); ?>" class="form-control mb-3">

            <label for="">Status</label>
            <input type="text" name="status" value="<?php echo e($rekap_pemasangan->status); ?>" class="form-control mb-3">

            <label for="">Pengajuan</label>
            <input type="date" name="tgl_pengajuan" value="<?php echo e($rekap_pemasangan->tgl_pengajuan); ?>"
                class="form-control mb-3">

            <label for="">Registrasi</label>
            <input type="text" name="registrasi" value="<?php echo e($rekap_pemasangan->registrasi); ?>" class="form-control mb-3">

            <label for="">Marketing</label>
            <input type="text" name="marketing" value="<?php echo e($rekap_pemasangan->marketing); ?>" class="form-control mb-3">

            <br>
            <label for="">SN Modem Awal</label>
            <input type="text" id="sn_modem_awal" class="form-control" value="<?php echo e($rekap_pemasangan->sn_modem); ?>"
                readonly>

            <label for="sn_modem">Modem :</label>
            <select name="sn_modem" id="sn_modem" style="width: 100%;">
                <option value="" <?php echo e($rekap_pemasangan->sn_modem == null ? 'selected' : ''); ?>>Tidak Pilih Modem
                </option>
                <?php $__currentLoopData = $modems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($modem->sn_modem); ?>"
                        <?php echo e($rekap_pemasangan->sn_modem == $modem->sn_modem ? 'selected' : ''); ?>>
                        <?php echo e($modem->sn_modem); ?> - <?php echo e($modem->model); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>




            <div class="form-group mt-4">
                <label for="teknisi">Pilih Teknisi :</label>
                <div>
                    <?php
                        $teknisiTerpilih = explode(',', $rekap_pemasangan->teknisi); // Konversi string ke array
                    ?>
                    <?php
                        // Pecah string menjadi array dan hilangkan spasi di awal & akhir setiap elemen
                        $teknisiTerpilih = array_map('trim', explode(',', $rekap_pemasangan->teknisi));
                    ?>

                    <?php $__currentLoopData = ['Deden', 'Agisdut', 'Dindin', 'Mursidi', 'Isep', 'Indra', 'Adit', 'Johan', 'Gilang']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teknisi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="checkbox" name="teknisi[]" value="<?php echo e($teknisi); ?>"
                            <?php echo e(in_array($teknisi, $teknisiTerpilih) ? 'checked' : ''); ?>>
                        <?php echo e($teknisi); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>

            <button class="btn btn-primary btn-sm">Simpan</button> <br><br>
        </form>
    </div>
    //

    <script>
        $(document).ready(function() {
            $('#sn_modem').select2({
                placeholder: "Cari dan Pilih Modem",
                allowClear: true
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            // Inisialisasi Select2
            $('#sn_modem').select2({
                placeholder: "Cari dan Pilih Modem",
                allowClear: true
            });

            // Update SN Modem Awal ketika pilihan berubah
            $('#sn_modem').on('change', function() {
                let selectedModem = $(this).val();
                $('#sn_modem_awal').val(selectedModem ? selectedModem : ''); // Kosongkan jika tidak pilih
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\NDG BARU\dashboard2\resources\views/rekap_pemasangan/edit.blade.php ENDPATH**/ ?>