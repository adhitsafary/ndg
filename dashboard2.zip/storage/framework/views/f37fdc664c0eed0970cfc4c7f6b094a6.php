<?php $__env->startSection('konten'); ?>
    <div class="card m-5">
        <div class="">
            <h4>Tambah Modem Baru</h4><br>

            <form action="<?php echo e(route('modem.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="sn_modem" class="form-label">SN Modem</label>
                    <div class="d-flex w-100 justify-content-center align-items-center">
                        <?php
                            $sn = preg_match('/SN:([A-Za-z0-9]+)/', old('sn_modem'), $matches) ? $matches[1] : (preg_match('/&sn=([A-Za-z0-9]+)/', old('sn_modem'), $matches) ? $matches[1] : 'Tidak ditemukan');
                        ?>
                        <input type="text" class="form-control" id="sn_modem" name="sn_modem" value="<?php echo e($sn); ?>" required>
                        <img src="<?php echo e(asset('asset/img/icon/camera.png')); ?>" alt="Scan Barcode" id="startScanner"
                            style="width: 60px; height: 60px; cursor: pointer; margin-left: 10px;">
                    </div>
                </div>



                <div class="mb-3">
                    <label for="model" class="form-label">Model</label>
                    <input type="text" class="form-control" id="model" name="model" required>
                </div>
                <div class="mb-3">
                    <label for="tgl_keluar" class="form-label">Tanggal Keluar</label>
                    <input type="date" class="form-control" id="tgl_keluar" name="tgl_keluar">
                </div>
                <div class="mb-3">
                    <label for="user" class="form-label">User</label>
                    <input type="text" class="form-control" id="user" name="user">
                </div>
                <div class="mb-3">
                    <label for="id_mikrotik" class="form-label">ID MikroTik</label>
                    <input type="text" class="form-control" id="id_mikrotik" name="id_mikrotik">
                </div>
                <div class="mb-3">
                    <label for="keterangan" class="form-label">Keterangan</label>
                    <input type="text" class="form-control" id="keterangan" name="keterangan">
                </div>

                <button type="submit" class="btn btn-primary">Simpan</button>
            </form>

            <!-- Elemen untuk menampilkan kamera -->
            <div id="video-container" style="display: none;">
                <video id="scanner" autoplay muted playsinline></video>
            </div>
        </div>
    </div>

    <style>
        #video-container {
            display: block;
            margin-top: 20px;
            width: 100%;
            max-width: 400px;
            border: 2px solid #ccc;
            border-radius: 5px;
            overflow: hidden;
        }

        #scanner {
            width: 100%;
            height: auto;
        }
    </style>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/quagga/0.12.1/quagga.min.js"></script>
    <script>
        const startScanner = document.getElementById('startScanner');
        const videoContainer = document.getElementById('video-container');
        const scannerVideo = document.getElementById('scanner');
        const snModemInput = document.getElementById('sn_modem');

        function checkCameraPermissions() {
            navigator.mediaDevices.getUserMedia({
                    video: true
                })
                .then(() => {
                    console.log("Akses kamera diizinkan.");
                })
                .catch((error) => {
                    console.error("Gagal mengakses kamera:", error);
                    alert("Gagal mengakses kamera. Pastikan izin diberikan pada browser.");
                });
        }

        function startBarcodeScanner() {
            videoContainer.style.display = 'block';

            Quagga.init({
                inputStream: {
                    name: "Live",
                    type: "LiveStream",
                    target: scannerVideo,
                    constraints: {
                        facingMode: {
                            ideal: "environment"
                        },
                        width: {
                            min: 640,
                            ideal: 1280,
                            max: 1920
                        },
                        height: {
                            min: 480,
                            ideal: 720,
                            max: 1080
                        }
                    }
                },
                decoder: {
                    readers: ["code_128_reader", "ean_reader", "ean_13_reader", "upc_reader"]
                }
            }, function(err) {
                if (err) {
                    console.error("QuaggaJS error:", err);
                    alert("Gagal memulai scanner!");
                    return;
                }
                Quagga.start();
            });

            Quagga.onDetected(function(data) {
                const barcode = data.codeResult.code;
                console.log("Kode Barcode:", barcode);
                snModemInput.value = barcode;
                Quagga.stop();
                videoContainer.style.display = 'none';
            });
        }

        startScanner.addEventListener('click', function() {
            checkCameraPermissions();
            startBarcodeScanner();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\dashboard2\resources\views/modem/create.blade.php ENDPATH**/ ?>