<?php $__env->startSection('konten'); ?>
    <div class="card m-5">
        <div class="card m-5">
            <a href="/modem/create/" class="btn btn=primary">Tambah data</a>
        </div>
        <div class="row">
            <?php $__currentLoopData = $modem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5><?php echo e($modem->model); ?></h5>
                        </div>
                        <div class="card-body">
                            <p><strong>SN Modem:</strong>
                                <?php echo e(preg_match('/SN:([A-Za-z0-9]+)/', $modem->sn_modem, $matches) ? $matches[1] : (preg_match('/&sn=([A-Za-z0-9]+)/', $modem->sn_modem, $matches) ? $matches[1] : 'Tidak ditemukan')); ?>

                            </p>
                            <p><strong>Tanggal Keluar:</strong> <?php echo e($modem->tgl_keluar); ?></p>
                            <p><strong>User:</strong> <?php echo e($modem->user); ?></p>
                            <p><strong>ID MikroTik:</strong> <?php echo e($modem->id_mikrotik); ?></p>
                            <p><strong>Keterangan:</strong> <?php echo e($modem->keterangan); ?></p>
                        </div>
                        <div class="card-footer">
                            <a href="<?php echo e(route('modem.edit', $modem->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('modem.destroy', $modem->id)); ?>" method="POST" class="d-inline-block">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger btn-sm"
                                    onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\dashboard2\resources\views/modem/index_hp.blade.php ENDPATH**/ ?>