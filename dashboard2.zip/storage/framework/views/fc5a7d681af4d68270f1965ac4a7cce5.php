<?php $__env->startSection('konten'); ?>
<div class="card m-5">
    <h2>Edit Modem</h2>

    <form action="<?php echo e(route('modem.update', $modem->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="sn_modem" class="form-label">SN Modem</label>
            <input type="text" class="form-control" id="sn_modem" name="sn_modem" value="<?php echo e($modem->sn_modem); ?>" >
        </div>
        <div class="mb-3">
            <label for="model" class="form-label">Model</label>
            <input type="text" class="form-control" id="model" name="model" value="<?php echo e($modem->model); ?>" >
        </div>
        <div class="mb-3">
            <label for="tgl_keluar" class="form-label">Tanggal Keluar</label>
            <input type="text" class="form-control" id="tgl_keluar" name="tgl_keluar" value="<?php echo e($modem->tgl_keluar); ?>" >
        </div>
        <div class="mb-3">
            <label for="user" class="form-label">User</label>
            <input type="text" class="form-control" id="user" name="user" value="<?php echo e($modem->user); ?>" >
        </div>
        <div class="mb-3">
            <label for="id_mikrotik" class="form-label">ID MikroTik</label>
            <input type="text" class="form-control" id="id_mikrotik" name="id_mikrotik" value="<?php echo e($modem->id_mikrotik); ?>" >
        </div>
        <div class="mb-3">
            <label for="keterangan" class="form-label">Keterangan</label>
            <textarea class="form-control" id="keterangan" name="keterangan"><?php echo e($modem->keterangan); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\dashboard2\resources\views/modem/edit.blade.php ENDPATH**/ ?>