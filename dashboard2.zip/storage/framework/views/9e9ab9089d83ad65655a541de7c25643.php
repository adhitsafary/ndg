<?php $__env->startSection('konten'); ?>
<div class="m-5">
    <h2 style="font: 600" class="text-center">DATA ODP BERDASARKAN DESA</h2>

    <a href="<?php echo e(route('odp.create')); ?>" class="btn btn-danger mb-3">Tambah ODP</a>

    <!-- Form Pencarian -->
    <form method="GET" action="<?php echo e(route('odp.index')); ?>" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control"
                placeholder="Cari berdasarkan Desa" value="<?php echo e($search ?? ''); ?>">
            <button type="submit" class="btn btn-primary">Cari</button>
        </div>
    </form>

    <?php if($odps->isEmpty()): ?>
        <div class="alert alert-warning text-center">
            Data tidak ditemukan.
        </div>
    <?php else: ?>
        <div class="row">
            <?php $__currentLoopData = $odps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $odp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title text-primary">
                                <a href="<?php echo e(route('odp.showByDesa', ['desa' => $odp->desa])); ?>" class="text-decoration-none">
                                    <?php echo e($odp->desa); ?>

                                </a>
                            </h5>
                            <p class="card-text">
                                <strong>Jumlah ODP:</strong> <?php echo e($odp->jumlah_odp); ?><br>
                                <strong>Jumlah Pelanggan:</strong> <?php echo e($odp->jumlah_pelanggan); ?>

                            </p>
                            <a href="<?php echo e(route('odp.showByDesa', ['desa' => $odp->desa])); ?>" class="btn btn-info btn-sm">
                                Detail Desa
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\dashboard2\resources\views/odp/index.blade.php ENDPATH**/ ?>