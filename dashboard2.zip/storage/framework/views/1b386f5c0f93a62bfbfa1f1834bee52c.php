<?php $__env->startSection('konten'); ?>
<div class="m-5">
    <h2 style="font: 600" >Detail: <?php echo e($nama_odp); ?></h1> <br>

    <table class="table table-striped">
        <thead class="table-dark">
            <tr>
                <th>Nama Pelanggan</th>
                <th>Alamat</th>
                <th>No Telepon</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pelanggan->nama_plg); ?></td>
                    <td><?php echo e($pelanggan->alamat_plg); ?></td>
                    <td><?php echo e($pelanggan->no_telepon_plg); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\dashboard2\resources\views/odp/show.blade.php ENDPATH**/ ?>