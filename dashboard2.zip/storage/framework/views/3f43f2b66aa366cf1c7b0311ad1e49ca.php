<?php $__env->startSection('konten'); ?>
    <div class="card m-5">
        <div class="mb-4" style="color: black;">
            <!-- Form Filter dan Pencarian -->
            <form action="<?php echo e(route('pengeluaran.index_jml')); ?>" method="GET" class="form-inline mb-4">
                <div class="input-group">
                    <input style="color: black;" type="text" name="search" id="search" class="form-control"
                        value="<?php echo e(request('search')); ?>" placeholder="Pencarian">
                    <div class="input-group-append">
                        <button type="submit" class="btn btn-danger">Cari</button>
                    </div>
                </div>
            </form>

            <!-- Tombol Buat pengeluaran Baru -->
            <div class="mb-3">
                <a href="/pengeluaran/create" class="btn btn-danger btn-sm">+ pengeluaran</a>
                <!-- Tombol Export dengan Dropdown -->
                <div class="mt-3">
                    <div class="dropdown">
                        <button class="btn btn-primary btn-sm dropdown-toggle" type="button" id="exportDropdown"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Export Data
                        </button>
                        <div class="dropdown-menu" aria-labelledby="exportDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('pengeluaran.exportExcel')); ?>">Export Excel</a>
                            <a class="dropdown-item" href="<?php echo e(route('pengeluaran.exportPdf')); ?>">Export PDF</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Judul -->
            <div class="text-center mb-5">
                <h5 class="font font-weight-bold" style="color: black;">Data pengeluaran Bulan Sekarang</h5>
            </div>

            <!-- Tabel Total pengeluaran Per Kategori -->
            <h5 class="font-weight-bold">Total pengeluaran Per Kategori:</h5>
            <table class="table table-bordered mb-4 text-center">
                <thead class="table-dark text-white">
                    <tr>
                        <?php
                            $warnaKategori = [
                                'table-primary',
                                'table-success',
                                'table-warning',
                                'table-danger',
                                'table-info',
                            ];
                            $totalPerKategori = $totalBulanan->groupBy('kategori')->map(function ($items) {
                                return $items->sum('harga_total');
                            });
                            $indexWarna = 0;
                        ?>
                        <?php $__currentLoopData = $totalPerKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th style="font-weight: 1000; color: black;"
                                class="<?php echo e($warnaKategori[$indexWarna % count($warnaKategori)]); ?>">
                                <?php echo e($kategori); ?>

                            </th>

                            <?php $indexWarna++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <?php $indexWarna = 0; ?>
                        <?php $__currentLoopData = $totalPerKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td style="font-weight: 1000">
                                <?php echo e(number_format($total)); ?>

                            </td>
                            <?php $indexWarna++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </tbody>
            </table>


            <!-- Tabel pengeluaran -->
            <table class="table table-bordered" style="color: black;">
                <thead class="table" style="color: black;">
                    <tr>
                        <th>No</th>
                        <th>Deskripsi</th>
                        <th>Harga Satuan</th>
                        <th>Volume</th>
                        <th>Harga Total</th>
                        <th>Kategori</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $kategoriSebelumnya = null;
                        $warnaKategori = [
                            'table-danger',
                            'table-success',
                            'table-warning',
                            'table-primary',
                            'table-info',
                        ];
                        $indexWarna = 0;
                    ?>

                    <?php $__empty_1 = true; $__currentLoopData = $totalBulanan->sortBy('kategori'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($kategoriSebelumnya !== $item->kategori): ?>
                            <?php
                                $kategoriSebelumnya = $item->kategori;
                                $warna = $warnaKategori[$indexWarna % count($warnaKategori)];
                                $indexWarna++;
                            ?>
                            <!-- Baris Header Kategori -->
                            <tr class="<?php echo e($warna); ?> font-weight-bold">
                                <td colspan="8" class=""><?php echo e($item->kategori); ?></td>
                            </tr>
                        <?php endif; ?>

                        <tr style="color: black">
                            <td><?php echo e($no + 1); ?></td>
                            <td><?php echo e($item->deskripsi); ?></td>
                            <td><?php echo e(number_format($item->harga_satuan)); ?></td>
                            <td><?php echo e($item->volume); ?></td>
                            <td><?php echo e(number_format($item->harga_total)); ?></td>
                            <td><?php echo e($item->kategori); ?></td>
                            <td><?php echo e($item->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('pengeluaran.edit', $item->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                <form action="<?php echo e(route('pengeluaran.destroy', $item->id)); ?>" method="POST"
                                    class="d-inline-block">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-danger btn-sm"
                                        onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center">Tidak ada data ditemukan</td>
                        </tr>
                    <?php endif; ?>

                    <!-- Baris total di bawah tabel -->
                    <tr class="table-dark text-black font-weight-bold">
                        <td colspan="4" class="text-center">TOTAL</td>
                        <td><?php echo e(number_format($totalJumlah)); ?></td>
                        <td colspan="3"></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\NDG BARU\dashboard2\resources\views/pengeluaran/index_jml.blade.php ENDPATH**/ ?>