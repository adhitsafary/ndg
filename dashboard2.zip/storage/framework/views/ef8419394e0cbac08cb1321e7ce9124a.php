<?php $__env->startSection('konten'); ?>
    <div class="card m-5">
        <h4>Daftar Token WhatsApp Bot</h4>

        <div class="row ml-2">
            <a href="<?php echo e(route('bot_tokens.create')); ?>" class="btn btn-primary mb-3 mr-2">Tambah Token</a>
            <a href="/bot_tokens/show/" class="btn btn-primary mb-3">Buat Token baru</a>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="card">

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>Nama</th>
                        <th>Token</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tokens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $token): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($token->name); ?></td>
                            <td><?php echo e($token->token); ?></td>
                            <td>
                                <a href="<?php echo e(route('bot_tokens.edit', $token)); ?>" class="btn btn-warning">Edit</a>
                                <form action="<?php echo e(route('bot_tokens.destroy', $token)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\baru\dashboard2\resources\views/bot_tokens/index.blade.php ENDPATH**/ ?>