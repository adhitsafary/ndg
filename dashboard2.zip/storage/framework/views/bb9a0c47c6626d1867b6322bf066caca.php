<?php $__env->startSection('konten'); ?>
    <div class="container mb-4" style="color: black;">
        <!-- Form Filter dan Pencarian -->
        <form action="<?php echo e(route('modem.index')); ?>" method="GET" class="form-inline mb-4 ">
            <div class="input-group">
                <input style="color: black;" type="text" name="search" id="search" class="form-control"
                    value="<?php echo e(request('search')); ?>" placeholder="Pencarian">
                <div class="input-group-append">
                    <button type="submit" class="btn btn-primary">Cari</button>
                </div>
            </div>
        </form>

        <a href="/modem/create" class="btn btn-danger">Tambah Modem</a>


        <div style="display: flex; justify-content: center;" class="mb-3">

            <h5 style="color: black;" class="font font-weight-bold">Data Modem</h5>
        </div>

        <table class="table table-bordered" style="color: black;">
            <thead class="table table-danger" style="color: black;">
                <tr>
                    <th>No</th>
                    <th>SN Modem</th>
                    <th>Model</th>
                    <th>Tanggal Keluar</th>
                    <th>User</th>
                    <th>ID MikroTik</th>
                    <th>Keterangan</th>
                    <td>Aksi</td>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $modem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $modem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="font font-weight-bold" style="color: black">
                        <td><?php echo e($no + 1); ?></td>
                        <td><?php echo e($modem->sn_modem); ?></td>
                        <td><?php echo e($modem->model); ?></td>
                        <td><?php echo e($modem->tgl_keluar); ?></td>
                        <td><?php echo e($modem->user); ?></td>
                        <td><?php echo e($modem->id_mikrotik); ?></td>
                        <td><?php echo e($modem->keterangan); ?></td>
                        <td> <a href="<?php echo e(route('modem.edit', $modem->id)); ?>" class="btn btn-warning btn-sm">Edit</a>

                            <form action="<?php echo e(route('modem.destroy', $modem->id)); ?>" method="POST"
                                class="d-inline-block">
                                <?php echo csrf_field(); ?>

                                <button class="btn btn-danger btn-sm"
                                    onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="13" class="text-center">Tidak ada data ditemukan</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ndg\dashboard2\resources\views/modem/index.blade.php ENDPATH**/ ?>