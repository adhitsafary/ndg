<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Absensi extends Model
{
    use HasFactory;
    
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    protected $table = 'absensi';

    protected $fillable = [
        'user_id',
        'foto',
        'jam_masuk',
        'titik_lokasi',
    ];


}
