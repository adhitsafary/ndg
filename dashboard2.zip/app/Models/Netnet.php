<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Net Digital Group extends Model
{
    use HasFactory;
    protected $table = 'perbaikan';
}
