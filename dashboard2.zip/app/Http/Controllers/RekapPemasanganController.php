<?php

namespace App\Http\Controllers;

use App\Models\GeneratorId;
use App\Models\KaryawanModel;
use App\Models\KasbonModel;
use App\Models\Modem;
use App\Models\Netnet;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Pelanggan;
use App\Models\RekapPemasanganModel;
use Maatwebsite\Excel\Facades\Excel;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class RekapPemasanganController extends Controller
{

    public function home()
    {

        $rekap_pemasangan = RekapPemasanganModel::all();

        // Kirim data ke view
        return view('rekap_pemasangan.index', compact('rekap_pemasangan'));
    }


    public function detail($id)
    {
        $rekap_pemasangan = RekapPemasanganModel::findOrFail($id);
        return view('rekap_pemasangan.detail', compact('rekap_pemasangan'));
    }


    public function index(Request $request)
    {
        $query = RekapPemasanganModel::query();
        $query->orderBy('created_at', 'desc');

        $paket_plg = $request->input('paket_plg');
        $paket_plg = $request->input('nama');
        $paket_plg = $request->input('marketing');
        $nominal = $request->input('nominal');
        $tgl_pengajuan = $request->input('tgl_pengajuan');
        $tgl_aktivasi = $request->input('tgl_aktivasi');
        $registrasi = $request->input('registrasi'); // Filter jumlah pembayaran

        // Filter tanggal created_at
        if ($request->filled('created_at_dari')) {
            $query->whereDate('created_at', '>=', $request->created_at_dari);
        }

        if ($request->filled('created_at_sampai')) {
            $query->whereDate('created_at', '<=', $request->created_at_sampai);
        }

        // Filter berdasarkan tanggal tagih
        if ($tgl_pengajuan) {
            $query->where('tgl_pengajuan', $tgl_pengajuan);
        }

        if ($registrasi) {
            $query->where('registrasi', $registrasi);
        }


        if ($tgl_aktivasi) {
            $query->whereDate('tgl_aktivasi', $tgl_aktivasi);
        }

        // Filter berdasarkan paket pelanggan
        if ($paket_plg) {
            $query->where('paket_plg', $paket_plg);
        }

        // Filter berdasarkan harga paket
        if ($nominal) {
            $query->where('nominal', $nominal);
        }

        // Pencarian berdasarkan berbagai kolom
        $search = $request->input('search');
        if ($search) {
            $query->where(function ($query) use ($search) {
                $query->where('id_plg', $search)
                    ->orWhere('marketing', 'like', "%{$search}%")
                    ->orWhere('nama', 'like', "%{$search}%")
                    ->orWhere('no_telpon', 'like', "%{$search}%")
                    ->orWhere('registrasi', 'like', "%{$search}%")
                    ->orWhere('alamat', 'like', "%{$search}%");
            });
        }

        $rekap_pemasangan = $query->get();


        return view('rekap_pemasangan.index', compact('rekap_pemasangan'));
    }

    public function create()
    {
        $modems = Modem::whereNull('user')->get(); // Hanya modem yang belum digunakan
        return view('rekap_pemasangan.create', compact('modems'));
    }

    public function store(Request $request)
    {
        // Validasi input
        $request->validate([
            'id_plg' => 'required|unique:rekap_pemasangan,id_plg',
            'nik' => 'required|string',
            'nama' => 'required|string|max:255',
            'alamat' => 'required|string',
            'no_telpon' => 'required|string',
            'paket_plg' => 'required|string',
            'harga_paket' => 'required|numeric',
            'tgl_pengajuan' => 'required|date',
            'tgl_aktivasi' => 'required|date',
            'sn_modem' => 'nullable|string',
            'registrasi' => 'required|string',
            'marketing' => 'required|string',
            'keterangan_plg' => 'required|string',
            'odp' => 'required|string',
            'longitude' => 'required|string',
            'latitude' => 'required|string',
        ]);

        // Kode perusahaan otomatis
        $kode_perusahaan = '9961';

        // Buat instance baru RekapPemasanganModel
        $rekap_pemasangan = new RekapPemasanganModel();
        $rekap_pemasangan->nik = $request->nik;
        $rekap_pemasangan->nama = $request->nama;
        $rekap_pemasangan->alamat = $request->alamat;
        $rekap_pemasangan->no_telpon = $request->no_telpon;
        $rekap_pemasangan->paket_plg = $request->paket_plg;
        $rekap_pemasangan->harga_paket = $request->harga_paket;
        $rekap_pemasangan->jt = Carbon::parse($request->tgl_aktivasi)->format('d');
        $rekap_pemasangan->status = 'Open';
        $rekap_pemasangan->tgl_pengajuan = $request->tgl_pengajuan;
        $rekap_pemasangan->registrasi = $request->registrasi;
        $rekap_pemasangan->marketing = $request->marketing;
        $rekap_pemasangan->keterangan_plg = $request->keterangan_plg;
        $rekap_pemasangan->id_plg = $request->id_plg;
        $rekap_pemasangan->odp = $request->odp;
        $rekap_pemasangan->longitude = $request->longitude;
        $rekap_pemasangan->latitude = $request->latitude;
        $rekap_pemasangan->tgl_aktivasi = $request->tgl_aktivasi;
        $rekap_pemasangan->sn_modem = $request->sn_modem;

        // Simpan data rekap_pemasangan ke database
        $rekap_pemasangan->save();

        // Simpan data GeneratorId setelah rekap_pemasangan disimpan
        // Membuat data GeneratorId baru
        $generatorId = new GeneratorId();
        $generatorId->kode_perusahaan = $kode_perusahaan;
        $generatorId->kode_nik = $rekap_pemasangan->nik;  // Mengambil NIK dari data rekap_pemasangan
        $generatorId->kode_odp = $rekap_pemasangan->odp;  // Mengambil ODP dari data rekap_pemasangan
        $generatorId->kode_paket_plg = $rekap_pemasangan->paket_plg; // Mengambil paket_plg dari data rekap_pemasangan

        // Simpan data GeneratorId yang baru
        $generatorId->save();

        return redirect()->route('rekap_pemasangan.index')->with('success', 'Data rekap pemasangan berhasil disimpan.');
    }




    public function store_2025_5(Request $request)
    {
        // Validasi bahwa `id_plg` harus unik
        $request->validate([
            'id_plg' => 'required|unique:rekap_pemasangan,id_plg',
            'nik' => 'required|string',
            'nama' => 'required|string|max:255',
            'alamat' => 'required|string',
            'no_telpon' => 'required|string',
            'paket_plg' => 'required|string',
            'harga_paket' => 'required|numeric',
            'tgl_pengajuan' => 'required|date',
            'tgl_aktivasi' => 'required|date',
            'sn_modem' => 'nullable|string',
            'registrasi' => 'required|string',
            'marketing' => 'required|string',
            'keterangan_plg' => 'required|string',
            'odp' => 'required|string',
            'longitude' => 'required|string',
            'latitude' => 'required|string',
        ]);

        // Ambil data GeneratorId pertama yang ada
        $generatorId = GeneratorId::first();

        // Jika data GeneratorId tidak ada, buat yang baru
        if (!$generatorId) {
            $generatorId = new GeneratorId();
            // Set default values untuk kode_perusahaan, kode_tahun, kode_nik, kode_odp
            $generatorId->kode_perusahaan = '9961';
            $generatorId->kode_nik = '000000000000'; // Set default untuk kode_nik
            $generatorId->kode_odp = '000'; // Set default untuk kode_odp
            $generatorId->paket_plg = '0'; // Set default untuk kode_tahun
            $generatorId->save(); // Simpan data GeneratorId baru
        }

        // Ambil 4 karakter dari kode_nik mulai dari posisi 12
        $nik = substr($generatorId->kode_nik, 11);

        // Ambil 3 karakter pertama dari kode_odp
        $odp = substr($generatorId->kode_odp, 0, 3);

        // Ambil paket_plg untuk paket_plg
        $paket_plg = $generatorId->paket_plg;

        // Kode perusahaan otomatis
        $kode_perusahaan = '9961';

        // Buat instance baru RekapPemasanganModel
        $rekap_pemasangan = new RekapPemasanganModel();

        // Isi data dari form dan tambahkan data otomatis
        $rekap_pemasangan->nik = $nik;
        $rekap_pemasangan->nama = $request->nama;
        $rekap_pemasangan->alamat = $request->alamat;
        $rekap_pemasangan->no_telpon = $request->no_telpon;
        $rekap_pemasangan->paket_plg = $paket_plg;
        $rekap_pemasangan->harga_paket = $request->harga_paket;
        $rekap_pemasangan->jt = Carbon::parse($request->tgl_aktivasi)->format('d');
        $rekap_pemasangan->status = 'Open';
        $rekap_pemasangan->tgl_pengajuan = $request->tgl_pengajuan;
        $rekap_pemasangan->registrasi = $request->registrasi;
        $rekap_pemasangan->marketing = $request->marketing;
        $rekap_pemasangan->keterangan_plg = $request->keterangan_plg;
        $rekap_pemasangan->id_plg = $request->id_plg;
        $rekap_pemasangan->odp = $odp;
        $rekap_pemasangan->longitude = $request->longitude;
        $rekap_pemasangan->latitude = $request->latitude;
        $rekap_pemasangan->tgl_aktivasi = $request->tgl_aktivasi;
        $rekap_pemasangan->sn_modem = $request->sn_modem;

        // Simpan data rekap_pemasangan ke database
        $rekap_pemasangan->save();

        // Perbarui user dan tgl_keluar pada tabel modem jika sn_modem disediakan
        if ($request->sn_modem) {
            $modem = Modem::where('sn_modem', $request->sn_modem)->first();
            if ($modem) {
                $modem->user = $request->nama;
                $modem->tgl_keluar = $rekap_pemasangan->created_at;
                $modem->save();
            }
        }

        // Setelah data rekap_pemasangan berhasil disimpan, simpan data GeneratorId
        $generatorId->kode_perusahaan = $kode_perusahaan;
        $generatorId->kode_nik = substr($rekap_pemasangan->nik, 0, 4); // Misalnya mengambil dari data yang diinput
        $generatorId->kode_odp = $rekap_pemasangan->odp;
        $generatorId->paket_plg = $rekap_pemasangan->paket_plg;

        $generatorId->save();

        return redirect()->route('rekap_pemasangan.index')->with('success', 'Data rekap pemasangan berhasil disimpan.');
    }


    public function store_2025_4(Request $request)
    {
        // Validasi bahwa `id_plg` harus unik
        $request->validate([
            'id_plg' => 'required|unique:rekap_pemasangan,id_plg',
            'nik' => 'required|string',
            'nama' => 'required|string|max:255',
            'alamat' => 'required|string',
            'no_telpon' => 'required|string',
            'paket_plg' => 'required|string',
            'harga_paket' => 'required|numeric',
            'tgl_pengajuan' => 'required|date',
            'tgl_aktivasi' => 'required|date',
            'sn_modem' => 'nullable|string',
            'registrasi' => 'required|string',
            'marketing' => 'required|string',
            'keterangan_plg' => 'required|string',
            'odp' => 'required|string',
            'longitude' => 'required|string',
            'latitude' => 'required|string',
        ]);

        // Buat instance baru RekapPemasanganModel
        $rekap_pemasangan = new RekapPemasanganModel();

        // Isi data dari form
        $rekap_pemasangan->nik = $request->nik;
        $rekap_pemasangan->nama = $request->nama;
        $rekap_pemasangan->alamat = $request->alamat;
        $rekap_pemasangan->no_telpon = $request->no_telpon;
        $rekap_pemasangan->paket_plg = $request->paket_plg;
        $rekap_pemasangan->harga_paket = $request->harga_paket;
        $rekap_pemasangan->jt = Carbon::parse($request->tgl_aktivasi)->format('d');
        $rekap_pemasangan->status = 'Open';
        $rekap_pemasangan->tgl_pengajuan = $request->tgl_pengajuan;
        $rekap_pemasangan->registrasi = $request->registrasi;
        $rekap_pemasangan->marketing = $request->marketing;
        $rekap_pemasangan->keterangan_plg = $request->keterangan_plg;
        $rekap_pemasangan->id_plg = $request->id_plg;
        $rekap_pemasangan->odp = $request->odp;
        $rekap_pemasangan->longitude = $request->longitude;
        $rekap_pemasangan->latitude = $request->latitude;
        $rekap_pemasangan->tgl_aktivasi = $request->tgl_aktivasi;
        $rekap_pemasangan->sn_modem = $request->sn_modem;

        // nik = kode_nik (ambil 4 huruf dari urutan 12 sampai terakhir)
        // odp = kode_odp (ambil 3 huruf)
        // paket_plg = kode_tahun (ambil semua)
        // tambakan kode_perusahaan otomatis jadi = 9961
        //created_at ambil dari created_at juga


        // Simpan data rekap_pemasangan ke database
        $rekap_pemasangan->save();

        // Perbarui user dan tgl_keluar pada tabel modem jika sn_modem disediakan
        if ($request->sn_modem) {
            $modem = Modem::where('sn_modem', $request->sn_modem)->first();
            if ($modem) {
                $modem->user = $request->nama;
                $modem->tgl_keluar = $rekap_pemasangan->created_at; // Menggunakan created_at dari rekap_pemasangan
                $modem->save();
            }
        }



        return redirect()->route('rekap_pemasangan.index')->with('success', 'Data rekap pemasangan berhasil disimpan.');
    }


    public function store_2025_3(Request $request)
    {
        // Validasi bahwa `id_plg` harus unik
        $request->validate([
            'id_plg' => 'required|unique:rekap_pemasangan,id_plg',
            'nik' => 'required|string',
            'nama' => 'required|string',
            'alamat' => 'required|string',
            'no_telpon' => 'required|string',
            'paket_plg' => 'required|string',
            'harga_paket' => 'required|numeric',
            'tgl_pengajuan' => 'required|date',
            'tgl_aktivasi' => 'required|date',
            'sn_modem' => 'nullable|string',
        ]);

        $rekap_pemasangan = new RekapPemasanganModel();

        // Input data dari form
        $rekap_pemasangan->nik = $request->nik;
        $rekap_pemasangan->nama = $request->nama;
        $rekap_pemasangan->alamat = $request->alamat;
        $rekap_pemasangan->no_telpon = $request->no_telpon;
        $rekap_pemasangan->paket_plg = $request->paket_plg;
        $rekap_pemasangan->harga_paket = $request->harga_paket;
        $rekap_pemasangan->jt = \Carbon\Carbon::parse($request->tgl_aktivasi)->format('d');
        $rekap_pemasangan->status = 'Open';
        $rekap_pemasangan->tgl_pengajuan = $request->tgl_pengajuan;
        $rekap_pemasangan->registrasi = $request->registrasi;
        $rekap_pemasangan->marketing = $request->marketing;
        $rekap_pemasangan->keterangan_plg = $request->keterangan_plg;
        $rekap_pemasangan->id_plg = $request->id_plg;
        $rekap_pemasangan->odp = $request->odp;
        $rekap_pemasangan->longitude = $request->longitude;
        $rekap_pemasangan->latitude = $request->latitude;
        $rekap_pemasangan->tgl_aktivasi = $request->tgl_aktivasi;
        $rekap_pemasangan->sn_modem = $request->sn_modem;

        $rekap_pemasangan->save();

        // Perbarui user pada tabel modem
        $modem = Modem::where('sn_modem', $request->sn_modem)->first();
        $modem = Modem::where('tgl_keluar', $request->created_at)->first();
        if ($modem) {
            $modem->user = $request->nama;
            $modem->save();
        }

        return redirect()->route('rekap_pemasangan.index')->with('success', 'Data rekap pemasangan berhasil disimpan.');
    }


    public function store_2025_2(Request $request)
    {
        $rekap_pemasangan = new RekapPemasanganModel();

        // Input data dari form
        $rekap_pemasangan->nik = $request->nik;
        $rekap_pemasangan->nama = $request->nama;
        $rekap_pemasangan->alamat = $request->alamat;
        $rekap_pemasangan->no_telpon = $request->no_telpon;
        $rekap_pemasangan->paket_plg = $request->paket_plg;
        $rekap_pemasangan->harga_paket = $request->harga_paket;
        $rekap_pemasangan->jt = \Carbon\Carbon::parse($request->tgl_aktivasi)->format('d');
        $rekap_pemasangan->status = 'Open';
        $rekap_pemasangan->tgl_pengajuan = $request->tgl_pengajuan;
        $rekap_pemasangan->registrasi = $request->registrasi;
        $rekap_pemasangan->marketing = $request->marketing;
        $rekap_pemasangan->keterangan_plg = $request->keterangan_plg;
        $rekap_pemasangan->id_plg = $request->id_plg;
        $rekap_pemasangan->odp = $request->odp;
        $rekap_pemasangan->longitude = $request->longitude;
        $rekap_pemasangan->latitude = $request->latitude;
        $rekap_pemasangan->tgl_aktivasi = $request->tgl_aktivasi;
        $rekap_pemasangan->sn_modem = $request->sn_modem;

        $rekap_pemasangan->save();

        // Perbarui user pada tabel modem
        $modem = Modem::where('sn_modem', $request->sn_modem)->first();
        if ($modem) {
            $modem->user = $request->nama;
            $modem->save();
        }

        return redirect()->route('rekap_pemasangan.index')->with('success', 'Data rekap_pemasangan berhasil disimpan.');
    }



    public function store_2025(Request $request)
    {
        $rekap_pemasangan = new RekapPemasanganModel();

        // Input data dari form
        $rekap_pemasangan->nik = $request->nik;
        $rekap_pemasangan->nama = $request->nama;
        $rekap_pemasangan->alamat = $request->alamat;
        $rekap_pemasangan->no_telpon = $request->no_telpon;
        $rekap_pemasangan->paket_plg = $request->paket_plg;
        $rekap_pemasangan->harga_paket = $request->harga_paket;
        $rekap_pemasangan->jt = \Carbon\Carbon::parse($request->tgl_aktivasi)->format('d');
        $rekap_pemasangan->status = 'Open';
        $rekap_pemasangan->tgl_pengajuan = $request->tgl_pengajuan;
        $rekap_pemasangan->registrasi = $request->registrasi;
        $rekap_pemasangan->marketing = $request->marketing;
        $rekap_pemasangan->keterangan_plg = $request->keterangan_plg;
        $rekap_pemasangan->id_plg = $request->id_plg;
        $rekap_pemasangan->odp = $request->odp;
        $rekap_pemasangan->longitude = $request->longitude;
        $rekap_pemasangan->latitude = $request->latitude;

        //tambahkan variable sn_modem dari model Modem

        // tgl_aktivasi opsional
        if ($request->filled('tgl_aktivasi')) {
            $rekap_pemasangan->tgl_aktivasi = $request->tgl_aktivasi;
        }

        $rekap_pemasangan->save();

        return redirect()->route('rekap_pemasangan.index')->with('success', 'Data rekap_pemasangan berhasil disimpan.');
    }

    public function store1(Request $request)
    {

        $rekap_pemasangan = new RekapPemasanganModel();

        $rekap_pemasangan->nik = $request->nik; // Nama dari form input
        $rekap_pemasangan->nama = $request->nama;
        $rekap_pemasangan->alamat = $request->alamat;
        $rekap_pemasangan->no_telpon = $request->no_telpon; // Nama dari form input
        $rekap_pemasangan->tgl_aktivasi = $request->tgl_aktivasi;
        $rekap_pemasangan->paket_plg = $request->paket_plg;
        $rekap_pemasangan->harga_paket = $request->harga_paket; // Nama dari form input harga paket
        $rekap_pemasangan->jt = \Carbon\Carbon::parse($request->tgl_aktivasi)->format('d'); //ini tgl tagih pelanggan

        $rekap_pemasangan->status = 'Request Pasang'; //ini status pembayaran
        $rekap_pemasangan->tgl_pengajuan = $request->tgl_pengajuan; // Nama dari form input
        $rekap_pemasangan->registrasi = $request->registrasi;
        $rekap_pemasangan->marketing = $request->marketing;

        $rekap_pemasangan->keterangan_plg = $request->keterangan_plg;

        $rekap_pemasangan->id_plg = $request->id_plg;
        $rekap_pemasangan->odp = $request->odp;
        $rekap_pemasangan->longitude = $request->longitude;
        $rekap_pemasangan->latitude = $request->latitude;

        $rekap_pemasangan->save();

        // Redirect ke halaman rekap_pemasangan index setelah penyimpanan berhasil
        return redirect()->route('rekap_pemasangan.index')->with('success', 'Data rekap_pemasangan berhasil disimpan.');
    }

    public function aktivasi($id)
    {
        // Ambil data rekap pemasangan berdasarkan ID
        $rekapPemasangan = RekapPemasanganModel::find($id);

        if (!$rekapPemasangan) {
            return redirect()->back()->with('error', 'Data pemasangan tidak ditemukan.');
        }

        // Cek apakah pelanggan sudah ada di tabel `pelanggan`
        $existingPelanggan = Pelanggan::where('id_plg', $rekapPemasangan->id_plg)->first();

        if ($existingPelanggan) {
            return redirect()->route('pelanggan.psb')->with('error', 'Pelanggan ini sudah diaktivasi.');
        }

        // Simpan data pelanggan baru
        $pelanggan = new Pelanggan();
        $pelanggan->id_plg = $rekapPemasangan->id_plg;
        $pelanggan->nama_plg = $rekapPemasangan->nama;
        $pelanggan->alamat_plg = $rekapPemasangan->alamat;
        $pelanggan->no_telepon_plg = $rekapPemasangan->no_telpon;
        $pelanggan->paket_plg = $rekapPemasangan->paket_plg;
        $pelanggan->harga_paket = $rekapPemasangan->harga_paket;
        $pelanggan->odp = $rekapPemasangan->odp;
        $pelanggan->longitude = $rekapPemasangan->longitude;
        $pelanggan->aktivasi_plg = $rekapPemasangan->tgl_aktivasi;
        $pelanggan->latitude = $rekapPemasangan->latitude;
        $pelanggan->tgl_tagih_plg = \Carbon\Carbon::now()->format('d'); // Tagih di hari ini
        // $pelanggan->tgl_tagih_plg = \Carbon\Carbon::parse($rekapPemasangan->tgl_aktivasi)->format('d'); //ini tgl tagih pelanggan
        $pelanggan->status_pembayaran = 'PSB'; // Status awal PSB

        $pelanggan->save();

        return redirect()->route('rekap_pemasangan.index')->with('success', 'Pelanggan berhasil diaktivasi.');
    }

    public function store2(Request $request)
    {

        $rekap_pemasangan = new RekapPemasanganModel();

        // Isi data rekap_pemasangan
        $rekap_pemasangan->nik = $request->nik; // Nama dari form input
        $rekap_pemasangan->nama = $request->nama;
        $rekap_pemasangan->alamat = $request->alamat;
        $rekap_pemasangan->no_telpon = $request->no_telpon; // Nama dari form input
        $rekap_pemasangan->tgl_aktivasi = $request->tgl_aktivasi;
        $rekap_pemasangan->paket_plg = $request->paket_plg;
        $rekap_pemasangan->harga_paket = $request->harga_paket; // Nama dari form input
        $rekap_pemasangan->jt = $request->jt;
        $rekap_pemasangan->status = $request->status;
        $rekap_pemasangan->tgl_pengajuan = $request->tgl_pengajuan; // Nama dari form input
        $rekap_pemasangan->registrasi = $request->registrasi;
        $rekap_pemasangan->marketing = $request->marketing;



        // Simpan data rekap_pemasangan ke database
        $rekap_pemasangan->save();

        // Redirect ke halaman rekap_pemasangan index setelah penyimpanan berhasil
        return redirect()->route('rekap_pemasangan.index')->with('success', 'Data rekap_pemasangan berhasil disimpan.');
    }

    public function show(string $id) {}


    public function edit(string $id_plg)
    {
        $rekap_pemasangan = RekapPemasanganModel::findOrFail($id_plg);
        return view('rekap_pemasangan.edit', compact('rekap_pemasangan'));
    }


    public function update(Request $request, string $id_plg)
    {
        $rekap_pemasangan = RekapPemasanganModel::findOrFail($id_plg);

        $rekap_pemasangan->id_plg = $request->id_plg;
        $rekap_pemasangan->nik = $request->nik; // Nama dari form input
        $rekap_pemasangan->nama = $request->nama;
        $rekap_pemasangan->alamat = $request->alamat;
        $rekap_pemasangan->no_telpon = $request->no_telpon; // Nama dari form input
        $rekap_pemasangan->tgl_aktivasi = $request->tgl_aktivasi;
        $rekap_pemasangan->paket_plg = $request->paket_plg;
        $rekap_pemasangan->harga_paket = $request->harga_paket; // Nama dari form input
        $rekap_pemasangan->jt = $request->jt;
        $rekap_pemasangan->status = $request->status;
        $rekap_pemasangan->tgl_pengajuan = $request->tgl_pengajuan; // Nama dari form input
        $rekap_pemasangan->registrasi = $request->registrasi;
        $rekap_pemasangan->marketing = $request->marketing;


        $rekap_pemasangan->save();

        return redirect()->route('rekap_pemasangan.index');
    }


    public function destroy(string $id_plg)
    {
        $rekap_pemasangan = RekapPemasanganModel::findOrFail($id_plg);
        $rekap_pemasangan->delete();

        return redirect()->route('rekap_pemasangan.index');
    }

    public function updateTglTagihPlg()
    {
        // Ambil semua pelanggan
        $pelanggans = Pelanggan::all();

        foreach ($pelanggans as $pelanggan) {

            if ($pelanggan->tgl_tagih_plg == ' jadi tanggal sekarang') {
            }
        }
    }
}
