<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css" />

  <!-- My CSS -->
  <link rel="stylesheet" href="css/style.css" class="rel" />
  <link rel="stylesheet" href="css/navbar_animation.css" class="rel" />

  <!-- My fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@700&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Kanit&family=Poppins:wght@600&display=swap" rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
    integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

  <title>NetNet Digital</title>
</head>

<body>
  <!-- NAVBAR -->
  <section class="navbar-sec">
    <nav class="navbar navbar-expand-lg fixed-top navbar-light ">
      <div class="container">
        <button class="navbar-toggler text-danger third-button" type="button" data-toggle="collapse"
          data-target="#navbarSupportedContent22" aria-controls="navbarSupportedContent22" aria-expanded="false"
          aria-label="Toggle navigation">
          <div class="animated-icon3"><span></span><span></span><span></span></div>
        </button>
        <a class="navbar-brand" href="#">Net</a>
        <div class="collapse navbar-collapse" id="navbarSupportedContent22">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Beranda<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Produk</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                aria-expanded="false">Promo </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Bantuan</a>
                <a class="dropdown-item" href="#">Tentang Kami</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Something else here</a>
              </div>
            <li class="nav-item">
              <a class="nav-link" href="#">Bantuan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Tentang Kami</a>
            </li>
            </li>
            <li class="nav-item">
              <a href="#" type="button" class="btn tombol">Daftar</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </section>

  <!-- Jumbotron -->
  <section id="jumbotron-sec">
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <div class="padding-jumbo">
          <div class="row">
            <div class="col-lg-6 align-self-center">
              <h1 class="display-4">Provider Baru Paling Worth It!</h1>
              <p class="lead">NetNet Digital memberikanmu paket internet termurah dengan pelayanan Terbaik.</p>
              <div class="btn-jumbo">
                <a href="#" type="button" class="btn tombol">Daftar</a>
                <a href="#" type="button" class="btn tombol-transparan"><i class="fas fa-map-marker-alt pr-3"></i>Cek
                  Jangkauan</a>
              </div>
            </div>
            <div class="col-lg-6 ">
              <img src="img/sally1.jpg" alt="gambar-jumbotron" class="img" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- home -->
  <div class="container">
    <div class="row text-center justify-content-center mt-5 mb-5">
      <div class="col-lg-5">
        <h1 class="title">Rekomendasi Paket Untukmu</h1>
      </div>
    </div>
  </div>
  <div class="container flex-container">
    <div class="card">
      <div class="header text-center">
        <h1 class="title">Hemat</h1>
        <img src="img/eclipse_speed.png" alt="kecepatan-bar" class="img" />
        <p class="title">15 MBPS</p>
      </div>
      <div class="content">
        <ul class="">
          <li>Unlimited</li>
          <li>5 Perangkat</li>
        </ul>
        <p>250.000</p>
      </div>
      <div class="text-center mt-4 content">
        <a href="#" type="button" class=" btn tombol-transparan ">Daftar</a>
      </div>
    </div>
    <div class="card besar">
      <div class="header text-center">
        <h1 class="title">Pas</h1>
        <img src="img/pas.png" alt="kecepatan-bar" class="img" />
        <p class="title">30 MBPS</p>
      </div>
      <div class="content">
        <ul class="">
          <li>Unlimited</li>
          <li>5 Perangkat</li>
        </ul>
        <p>320.000</p>
      </div>
      <div class="text-center content mt-4">
        <a href="#" type="button" class=" btn tombol ">Daftar</a>
      </div>
    </div>
    <div class="card">
      <div class="header text-center">
        <h1 class="title">Super</h1>
        <img src="img/super.png" alt="kecepatan-bar" class="img" />
        <p class="title">50 MBPS</p>
      </div>
      <div class="content">
        <ul class="">
          <li>Unlimited</li>
          <li>5 Perangkat</li>
        </ul>
        <p>400.000</p>
      </div>
      <div class="text-center content mt-4">
        <a href="#" type="button" class=" btn tombol-transparan">Daftar</a>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row mt-5">
      <div class="col-lg">
        <div class="text-center content out">
          <a href="#" type="button" class=" btn tombol-transparan">Lihat semua Paket</a>
        </div>
      </div>
    </div>
  </div>

  <!-- About -->
  <div class="about-bg"></div>
  <div class="about">
    <div class="container flex-container mt-5">
      <div class="row">
        <div class="col-lg-7 pb-5">
          <h1 class="title">Mengapa Harus Beralih ke NetNet Digital?</h1>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-6 align-self-center">
          <h1 class="title-brand ">Net</h1>
        </div>
        <div class="col-lg-6">
          <p class="info">NetNet Digital merupakan provider masa kini yang membuatmu semakin maju. Sekarang kamu dapat memasang
            provider
            dirumahmu sendiri dengan hanya Rp 165.000 saja! NetNet Digital selalu mengedepankan kualitas dengan harga paling
            terjangkau se-Indonesia</p>
          <div class="text-center">
            <a href="#" type="button" class=" btn tombol">Lihat semua Paket</a>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="card-about">
          <div class="card-featured text-lg-center">
            <div class="rectangle text-center  ">
              <img src="img/rocket.png" alt="super-ngebut" class="img" />
            </div>
            <h1>Super Ngebut</h1>
            <p>Rasakan Internet Ngebut tanpa lag hingga 50 mbps</p>
          </div>
          <div class="card-featured text-lg-center ">
            <div class="rectangle text-center ">
              <img src="img/fiber.png" alt="super-ngebut" class="img" />
            </div>
            <h1>Fiber Optic</h1>
            <p>Rasakan kecepatan internet yang lebih stabil di segala kondisi </p>
          </div>
          <div class="card-featured text-lg-center">
            <div class="rectangle text-center ">
              <img src="img/money.png" alt="super-ngebut" class="img" />
            </div>
            <h1>Paling Murah</h1>
            <p>NetNet Digital memberikanmu harga termurah dibandingkan provider lainnya</p>
          </div>
          <div class="card-featured text-lg-center">
            <div class="rectangle text-center">
              <img src="img/call.png" alt="super-ngebut" class="img" />
            </div>
            <h1>CS 24 Jam</h1>
            <p>Hubungi NetNet Digital kapan saja, Customer Service kami siap melayani 24 jam</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Konsultasi -->
  <div class="konsul">
    <div class="container flex-container">
      <div class="row">
        <div class="col-lg-6 align-self-center ">
          <h1>Bingung Memilih Paketmu?</h1>
          <p>Tenang, kamu dapat menghubungi Mister Net untuk berkonsultasi mengenai paket yang paling cocok dengan
            kamu.
            Yuk! Segera tanya Mister Net sekarang!</p>
        </div>
        <div class="col-lg-6">
          <img src="img/people.png" alt="konsultasi" class="img">
        </div>
      </div>
    </div>
  </div>
  </div>



  <!-- Footer -->
  <footer>
    <div class="container flex-container">
      <div class="row">
        <div class="col-lg-6">
          <h1>Area Cakupan NetNet Digital</h1>
          <div class="card-footers">
            <a href="#">Cisarua</a>
            <a href="#">Cijeruk</a>
            <a href="#">Griya goal para</a>
            <a href="#">Cisarua</a>
            <a href="#">Cijeruk</a>
            <a href="#">Griya goal para</a>
            <a href="#">Cisarua</a>
            <a href="#">Cijeruk</a>
            <a href="#">Griya goal para</a>
            <a href="#">Cisarua</a>
            <a href="#">Cijeruk</a>
            <a href="#">Griya goal para</a>
          </div>
        </div>
        <div class="col-lg-3">
          <h1>Customer Service</h1>
          <div class="card-footers2">
            <p>Untuk keluhan dan gangguan </p>
            <div class="padding-footer">
              <h2>082123852983</h2>

            </div>
          </div>
          <button type="submit" class="btn tombol">Telpon</button>
        </div>
        <div class="col-lg-3">
          <h1>Kontak Kami</h1>
          <p>Untuk berlangganan produk NetNet Digital</p>
          <div class="padding-footer2">
            <h2>082123852983</h2>

          </div>
          <button type="submit" class="btn tombol">Telpon</button>
        </div>
      </div>
    </div>
    <div class="row title-brand-footer justify-content-center">

    </div>
    <div class="row icon-awesome justify-content-center">
      <a href="https://www.facebook.com/sandro.manullang.90" class=""><i class="fab fa-facebook fa-3x mr-3"></a></i>
      <a href="https://www.linkedin.com/in/sandro-hamonangan-25b0231b3/" class=""><i
          class="fab fa-linkedin fa-3x mr-3 "></a></i>
      <a href="https://www.instagram.com/sandroomanulang/" class=""><i class="fab fa-instagram fa-3x mr-3 "></a></i>
      <a href="https://www.facebook.com" class=""><i class="fab fa-whatsapp fa-3x mr-3 "></a></i>
      <a href="https://www.facebook.com" class=""><i class="fas fa-envelope fa-3x mr-3 "></a></i>
    </div>
    </div>
  </footer>


  <script src="js/jquery.slim.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/script.js"></script>
</body>

</html>
