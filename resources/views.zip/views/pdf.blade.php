<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Laporan Perbaikan</title>
    <style>
        /* Custom PDF styling */
    </style>
</head>

<body>
    <h1>Laporan Perbaikan</h1>
    <p>Total Perbaikan: {{ $perbaikan->count() }}</p>
    <table>
        <!-- Tabel perbaikan untuk PDF -->
    </table>
</body>

</html>
