@extends($layout)

@section('konten')
<div class="d-flex vh-100 justify-content-center align-items-center">
    <div class="text-center">
        <img src="{{ asset('asset/img/logo.png') }}" alt="Logo" style="width: 150px;">
        <h2 class="mt-4 text-center">Absensi <br> Net Digital Group</h2>
    </div>
</div>
@endsection
